//
//  APODViewModel.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 11/12/21.
//

import Foundation

protocol APODViewModelProtocol:AnyObject {
    
    func refreshAPOD()
    func showError()
}

class APODViewModel {
    
    weak var apodViewModelProtocol:APODViewModelProtocol?
    
    var apodDetail:APODModel? {
        didSet{
            apodViewModelProtocol?.refreshAPOD()
        }
    }
    
    var errorMessage:String?
    {
        didSet{
            apodViewModelProtocol?.showError()
        }
    }
    
    
    func getAPODDetails(_ currentDate:String)
    {
        NetWorkWrapper().getAPODDetails(currentDate: currentDate) { (result) in
            switch result
            {
            case .success(let data):
                if let request = JSONSerialization.paserJSONData(data) as? NSDictionary
                {
                    Utility.customLog(request)
                    
                    if let model = request.jsonObject(ofType: APODModel.self)
                    {
                        self.apodDetail = model
                    }
                    
                }
            case .failure(let error):
                Utility.customLog(error.localizedDescription)
                self.errorMessage = error.localizedDescription
            }
        }
    }
}
