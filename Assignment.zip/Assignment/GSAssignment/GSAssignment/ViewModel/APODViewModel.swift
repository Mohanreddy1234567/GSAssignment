//
//  APODViewModel.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 11/12/21.
//

import Foundation
import UIKit

protocol APODViewModelProtocol:AnyObject {
    
    func refreshAPOD()
    func showError()
    func refreshAPODWithNewDate(newDate:String)
}

class APODViewModel {
    
    weak var apodViewModelProtocol:APODViewModelProtocol?
    let datePicker = UIDatePicker()
    var toolBar = UIToolbar()
  
    var apodDetail:APODModel? {
        didSet{
            apodViewModelProtocol?.refreshAPOD()
        }
    }
    
    var errorMessage:String?
    {
        didSet{
            apodViewModelProtocol?.showError()
        }
    }
    
    
    func getAPODDetails(_ currentDate:String)
    {
        NetWorkWrapper().getAPODDetails(currentDate: currentDate) { (result) in
            switch result
            {
            case .success(let data):
                if let request = JSONSerialization.paserJSONData(data) as? NSDictionary
                {
                    Utility.customLog(request)
                    
                    if let model = request.jsonObject(ofType: APODModel.self)
                    {
                        self.apodDetail = model
                    }
                    
                }
            case .failure(let error):
                Utility.customLog(error.localizedDescription)
                self.errorMessage = error.localizedDescription
            }
        }
    }
    
    func showDatePicker(_ searchButton:UIBarButtonItem, viewController:UIViewController) {

        datePicker.backgroundColor = UIColor.white
        
        datePicker.autoresizingMask = .flexibleWidth
        datePicker.datePickerMode = .date
        datePicker.timeZone = TimeZone.init(identifier: "UTC")

        datePicker.addTarget(self, action: #selector(self.dateChanged(_:)), for: .valueChanged)
        datePicker.frame = CGRect(x: 0.0, y: UIScreen.main.bounds.size.height - 250, width: UIScreen.main.bounds.size.width, height: 250)
        
        viewController.view.addSubview(datePicker)
        
        toolBar = UIToolbar(frame: CGRect(x: 0, y: UIScreen.main.bounds.size.height - 250, width: UIScreen.main.bounds.size.width, height: 50))
        
        let doneButton = UIBarButtonItem(title: "DONE", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.onDoneButtonClick))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "CANCEL", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.cancelDatePicker))
        
        toolBar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
        toolBar.sizeToFit()
        viewController.view.addSubview(toolBar)
    }
    
    // MARK: - dateChanged Methods
    @objc func dateChanged(_ sender: UIDatePicker?) {
        let dateFormatter = self.getDateFormatter()
        
        var selectedDate:String? = nil
        
        if let date = sender?.date {
            selectedDate  = dateFormatter.string(from: date)
        }
        
        Utility.storeSelectedDate(selectedDate)
    }
    
    // MARK: - onDoneButtonClick Methods
    @objc func onDoneButtonClick() {
      
        self.removePickerView()

        if let existingDate = Utility.fetchSelectedDate()
        {
            apodViewModelProtocol?.refreshAPODWithNewDate(newDate: existingDate)
        }
    }
 
    // MARK: - cancelDatePicker Methods
    @objc func cancelDatePicker() {
        self.removePickerView()
    }
    
    // MARK: - removePickerView Methods
    private func removePickerView()
    {
        toolBar.removeFromSuperview()
        datePicker.removeFromSuperview()
    }
    
    // MARK: - getDateFormatter Methods
    func getDateFormatter() -> DateFormatter
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = defaultDateFormat
        dateFormatter.calendar = Calendar.current
        dateFormatter.locale = Locale.current
        dateFormatter.timeZone = TimeZone.current
        
        return dateFormatter
    }
    
    // MARK: - getCurrentDate Methods
    func getCurrentDate() ->String
    {
        let date = Date()
        let dateFormatter = self.getDateFormatter()
        Utility.storeSelectedDate(dateFormatter.string(from: date))
        
        return dateFormatter.string(from: date)
    }
    
}
