//
//  Constants.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 11/12/21.
//

import Foundation
import UIKit

enum Backend {
    static let apiKey =  "DEMO_KEY"  //"TeQNB5N9rmKjJuI1akHrnaDQAmXagp3FspkASjs0"
    static let host = "https://api.nasa.gov"
}

let defaultDateFormat = "yyyy-MM-dd"
