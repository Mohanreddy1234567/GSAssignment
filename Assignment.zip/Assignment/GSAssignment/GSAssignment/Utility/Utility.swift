//
//  Utility.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 10/12/21.
//

import Foundation
import UIKit

class Utility: NSObject {
    
    
    static func customLog(_ message:Any)
    {
        #if DEBUG
        debugPrint("Debug: %@", message as! CVarArg)
        #endif
    }
    
    static func error(_ message: String, code: Int = 0, domain: String = "") -> NSError {
        
        let error = NSError(domain: domain, code: code, userInfo: [
            NSLocalizedDescriptionKey: message,
        ])
        
        return error
    }
    
    static func storeSelectedDate ( _ date:String?)
    {
        UserDefaults.standard.set(date, forKey: "selectedDate")
    }
    
    static func fetchSelectedDate() -> String?
    {
        return UserDefaults.standard.object(forKey: "selectedDate") as? String
    }
    
    static func storeAPODModel ( _ model:[APODModel])
    {
        let encoder = JSONEncoder()
        
        if let data = try? encoder.encode(model) {
            UserDefaults.standard.set(data, forKey: "apodModel")
        }
    }
    
    static func fetchAPODModel() -> [APODModel]?
    {
        if let data = UserDefaults.standard.data(forKey: "apodModel")
        {
            let apodArray = try! JSONDecoder().decode([APODModel].self, from: data)
            return apodArray
        }
        return nil
    }
    
    static func storeLastViewAPODModel ( _ model:APODModel)
    {
        let encoder = JSONEncoder()
        
        if let data = try? encoder.encode(model) {
            UserDefaults.standard.set(data, forKey: "apodLastViewModel")
        }
    }
    
    static func fetchLastViewAPODModel() -> APODModel?
    {
        if let data = UserDefaults.standard.data(forKey: "apodLastViewModel")
        {
            let objectArray = try! JSONDecoder().decode(APODModel.self, from: data)
            return objectArray
        }
        return nil
    }
    
    static func showEddError (_ error:String,viewController:UIViewController) {
        DispatchQueue.main.async {
            
            let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
            if let errorVC = mainStoryBoard.instantiateViewController(withIdentifier: "ErrorViewController") as? ErrorViewController
            {
                errorVC.errorMessage = error
                errorVC.modalPresentationStyle = .custom
                viewController.present(errorVC, animated: true, completion: nil)
            }
        }
    }
}
