//
//  PublicKeyPinningHandler.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 10/12/21.
//

import Foundation
import UIKit
import CommonCrypto

class PublicKeyPinningHandler {
    
    var publicKeys: [String]?
    
    let rsa2048Asn1Header: [UInt8] = [
        0x30, 0x82, 0x01, 0x22, 0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86,
        0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00, 0x03, 0x82, 0x01, 0x0f, 0x00
    ]
    
    private func sha256(data: Data) -> String {
        var keyWithHeader = Data(rsa2048Asn1Header)
        keyWithHeader.append(data)
        var hash = [UInt8](repeating: 0,  count: Int(CC_SHA256_DIGEST_LENGTH))
           keyWithHeader.withUnsafeBytes {
               _ = CC_SHA256($0.baseAddress, CC_LONG(keyWithHeader.count), &hash)
           }
        return Data(hash).base64EncodedString()
    }
    
    func parsePublicSecKey(publicKey: SecKey) -> NSData? {
        var data: NSData?
        
        if #available(iOS 10.0, *) {
            data = SecKeyCopyExternalRepresentation(publicKey, nil)
        } else {

            let tempTag = Utility.getChannelIDs().domain
            
            let addParameters: [String: AnyObject] = [
                String(kSecClass): kSecClassKey,
                String(kSecAttrApplicationTag): tempTag as AnyObject,
                String(kSecAttrKeyType): kSecAttrKeyTypeRSA,
                String(kSecValueRef): publicKey,
                String(kSecReturnData): kCFBooleanTrue
            ]
            
            var keyPtr: AnyObject?
            
            // Add to Keychain temp
            var status = SecItemAdd(addParameters as CFDictionary, &keyPtr)
            
            if status == errSecSuccess {
                data = keyPtr as? NSData
            } else if status == errSecDuplicateItem {
                status = SecItemCopyMatching(addParameters as CFDictionary, &keyPtr)
                
                if status == errSecSuccess {
                    data = keyPtr as? NSData
                }
            }
            SecItemDelete(addParameters as CFDictionary)
            
        }
        
        return data
    }
    
    func validatePublicKey(serverTrust: SecTrust) -> Bool {
        var isValid: Bool = false
        
        if let serverCertificate = SecTrustGetCertificateAtIndex(serverTrust, 0) {
            if let serverPublicKey: SecKey = getPublicKeyFromCertificate(serverCertificate: serverCertificate) {
                if let serverPublicKeyData: NSData = parsePublicSecKey(publicKey: serverPublicKey) {
                    let keyHash = sha256(data: serverPublicKeyData as Data)
                    
                    if self.publicKeys?.contains(keyHash) == true {
                        isValid = true
                    }
                }
                
            }
            
        }
        return isValid
        
    }
    
    func getPublicKeyFromCertificate(serverCertificate: SecCertificate) -> SecKey? {
        var serverPublicKey: SecKey?
        
        if #available(iOS 10.3, *) {
            if #available(iOS 12.0, *) {
                serverPublicKey = SecCertificateCopyKey(serverCertificate)
            } else {
                serverPublicKey = SecCertificateCopyPublicKey(serverCertificate)
            }
        } else {
            var secTrust: SecTrust?
            let secTrustStatus = SecTrustCreateWithCertificates(serverCertificate, nil, &secTrust)
            if secTrustStatus == errSecSuccess {
                serverPublicKey = SecTrustCopyPublicKey(secTrust!)!
            }
            
        }
        
        return serverPublicKey
    }
    
    func validateCertificate(serverTrust: SecTrust) -> Bool {
        var isValid: Bool = false
        
        let remoteCertificateData: Data? = getServerCertificate(serverTrust: serverTrust)
        let localCertificateData: Data? = getLocalCertificate()
        
        if remoteCertificateData != nil && localCertificateData != nil {
            isValid = (remoteCertificateData == localCertificateData)
        }
        return isValid
        
    }
    
    func getLocalCertificate() -> Data? {
        let bundle = Bundle.currentBundle()

        let pathToCert = bundle.path(forResource: "sit-apig.jiomoney.com", ofType: "cer")
        return NSData(contentsOfFile: pathToCert!) as Data?
    }
    
    func getServerCertificate(serverTrust: SecTrust) -> Data? {
        let certificate = SecTrustGetCertificateAtIndex(serverTrust, 0)
        return SecCertificateCopyData(certificate!) as Data
    }

}
