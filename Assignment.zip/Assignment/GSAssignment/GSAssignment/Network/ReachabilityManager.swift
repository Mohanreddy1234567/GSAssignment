//
//  ReachabilityManager.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 11/12/21.
//

import Foundation
import Reachability

class ReachabilityManager {
    
    // Boolean to track network reachability
    var isNetworkAvailable : Bool = false
    
    // Tracks current NetworkStatus (notReachable, reachableViaWiFi, reachableViaWWAN)
    var reachabilityStatus: Reachability.Connection = .unavailable
     //Reachability instance for Network status monitoring
    var reachability:Reachability?
    static  let shared = ReachabilityManager()
    
    init() {
        do {
            reachability = try Reachability(hostname: Backend.host )
            
            NotificationCenter.default.addObserver(self, selector: #selector(ReachabilityManager.reachabilityChanged(notification:)), name: NSNotification.Name.reachabilityChanged, object: nil)
            
            try reachability?.startNotifier()
        } catch{
            debugPrint(error)
        }
    }
    
    /// Called whenever there is a change in NetworkReachibility Status
    ///
    /// — parameter notification: Notification with the Reachability instance
    @objc func reachabilityChanged(notification: Notification) {
        if  let reachability = notification.object as? Reachability {
            
            switch reachability.connection {
                
            case .unavailable:
                isNetworkAvailable =  false
                debugPrint("Network became unreachable")
            case .wifi:
                isNetworkAvailable =  true
                debugPrint("Network reachable through WiFi")
            case .cellular:
                isNetworkAvailable =  true
                debugPrint("Network reachable through Cellular Data")
            case .none:
                isNetworkAvailable =  false
                debugPrint("Network became unreachable")
            }
        }
    }
    
    func startMonitoring() {
        NotificationCenter.default.addObserver(self, selector: #selector(ReachabilityManager.reachabilityChanged(notification:)), name: NSNotification.Name.reachabilityChanged, object: nil)
        do{
            try reachability?.startNotifier()
        } catch {
            debugPrint("Could not start reachability notifier")
        }
    }
}
