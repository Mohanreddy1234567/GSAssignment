//
//  NetWorkWrapper.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 11/12/21.
//

import Foundation

class NetWorkWrapper: NSObject {
    
    let contentDataOperator = ServiceHandler.shared()
    
    func getAPODDetails(currentDate: String, CompleteHandle:@escaping(Result<Data, NSError>)-> Void)
    {
        var iServiceObject  = ServiceRequest()
        iServiceObject.body = nil
        iServiceObject.header = nil
        iServiceObject.url = Backend.host + "/planetary/apod?api_key=" + Backend.apiKey + "&date=" + currentDate
        iServiceObject.type = RequestType.GET
        
        contentDataOperator.getDataForService(request: iServiceObject) { (result) in
            CompleteHandle(result)
        }
    }
}
