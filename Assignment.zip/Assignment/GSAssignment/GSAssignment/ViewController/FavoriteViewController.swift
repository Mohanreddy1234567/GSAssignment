//
//  FavoriteViewController.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 11/12/21.
//

import UIKit

class FavoriteViewController: UIViewController{
    
    @IBOutlet weak var favTableView: UITableView!
    
    var apodModelArray = [APODModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.regiserNIB()
        self.title = "Favorite Details"
        
        self.apodModelArray = Utility.fetchAPODModel() ?? []
    }
    
    // MARK: - Private Methods
    private func regiserNIB()
    {
        favTableView.tableFooterView = UIView()
        favTableView.estimatedRowHeight = 50.0
        favTableView.rowHeight = UITableView.automaticDimension
        favTableView.register(UINib(nibName: "APODCell", bundle: nil), forCellReuseIdentifier: "APODCell")
    }
}

extension FavoriteViewController:UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        if apodModelArray.count > 0
        {
            return apodModelArray.count
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell: APODCell = tableView.dequeueReusableCell(withIdentifier: "APODCell", for: indexPath as IndexPath) as? APODCell {

            if indexPath.row < self.apodModelArray.count
            {
                let model:APODModel = self.apodModelArray[indexPath.row]
                cell.selectionStyle = .none
                cell.parentVC = self
                cell.delegate = self
                cell.isFromFavorite = true
                
                cell.setAPODObject(model, index: indexPath.row)
            }
           
            return cell
        }
        
        return UITableViewCell()
    }
}

extension FavoriteViewController:APODCellProtocol
{
    func deleteFav(index: Int) {
    
        let alertController = UIAlertController(title: "Delete Favorites", message: "Please select below option", preferredStyle: .actionSheet)
        
        alertController.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { action in

            if index < self.apodModelArray.count
            {
                self.apodModelArray.remove(at: index)
                Utility.storeAPODModel(self.apodModelArray)
                DispatchQueue.main.async {
                    self.favTableView.reloadData()
                }
            }
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        present(alertController, animated: true, completion: nil)
    }
}

