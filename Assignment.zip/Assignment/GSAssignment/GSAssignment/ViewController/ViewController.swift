//
//  ViewController.swift
//  GSAssignment
//
//  Created by Mohanreddy Batchu on 10/12/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    let apodViewModel:APODViewModel = APODViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.regiserNIB()
        self.initNavBar()
        
        apodViewModel.apodViewModelProtocol = self
        tableView.showLoading()
        apodViewModel.getAPODDetails(apodViewModel.getCurrentDate())
    }
    
    private func initNavBar()
    {
        self.title = "Astronomy picture of the day"
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Search", style: .plain, target: self, action: #selector(searchPictureByDate(_ :)))
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Favorite", style: .plain, target: self, action: #selector(viewFavorite))
    }
    
    private func regiserNIB()
    {
        tableView.tableFooterView = UIView()
        tableView.estimatedRowHeight = 50.0
        tableView.rowHeight = UITableView.automaticDimension
        tableView.register(UINib(nibName: "APODCell", bundle: nil), forCellReuseIdentifier: "APODCell")
    }
    
    // MARK: - IBAction Methods
    @IBAction func searchPictureByDate(_ sender: Any)
    {
        apodViewModel.showDatePicker(sender as! UIBarButtonItem, viewController: self)
    }
    
    @IBAction func viewFavorite(_ sender: Any)
    {
        DispatchQueue.main.async
        {
            let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
            if let favVC = mainStoryBoard.instantiateViewController(withIdentifier: "FavoriteViewController") as? FavoriteViewController
            {
                self.navigationController?.pushViewController(favVC, animated: true)
            }
        }
    }
}

extension ViewController:APODViewModelProtocol
{
    func refreshAPODWithNewDate(newDate: String) {
        
        self.tableView.showLoading()
        apodViewModel.getAPODDetails(newDate)
    }
    
    func showError() {
        DispatchQueue.main.async {
            self.tableView.stopLoading()
            
            if let model = Utility.fetchLastViewAPODModel()
            {
                self.apodViewModel.apodDetail = model
                self.tableView.reloadData()
            }
            
            if let error  = self.apodViewModel.errorMessage
            {
                let displayError = "Error Message: "+error
                Utility.showEddError(displayError, viewController:self)
            }
        }
    }
    
    func refreshAPOD() {
        DispatchQueue.main.async {
            
            if let model = self.apodViewModel.apodDetail
            {
                Utility.storeLastViewAPODModel(model)
            }
            
            self.tableView.stopLoading()
            self.tableView.reloadData()
        }
    }
}


extension ViewController:UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if apodViewModel.apodDetail != nil
        {
            return 1
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell: APODCell = tableView.dequeueReusableCell(withIdentifier: "APODCell", for: indexPath as IndexPath) as? APODCell {

            cell.selectionStyle = .none
            cell.delegate = self
            cell.parentVC = self
            
            cell.setAPODObject(apodViewModel.apodDetail)
           
            return cell
        }
        
        return UITableViewCell()
    }
}

extension ViewController:APODCellProtocol
{
    func addFav() {
        
        let alertController = UIAlertController(title: "Add Favorites", message: "Please select below option", preferredStyle: .actionSheet)
        
        alertController.addAction(UIAlertAction(title: "Add", style: .destructive, handler: { action in
            
            if let model = self.apodViewModel.apodDetail, let date = model.date
            {
                var apodModelArray = [APODModel]()
                
                apodModelArray = Utility.fetchAPODModel() ?? []
                
                let apodObject:[APODModel]? = apodModelArray.filter({ (apodModel) -> Bool in
                    return apodModel.date?.caseInsensitiveCompare(date) == ComparisonResult.orderedSame
                })
                
                if apodObject?.count == 0
                {
                    apodModelArray.append(model)
                    Utility.storeAPODModel(apodModelArray)
                }
            }
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        present(alertController, animated: true, completion: nil)
    }
}

